Decision_Tree.ipynb --> This file contains the code for decision tree classifier.
KNN.ipynb --> KNN classifier
Random_Forest.ipynb --> Random forest classifier.

train.csv --> Dataset used by .ipynb files
